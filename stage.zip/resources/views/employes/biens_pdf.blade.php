<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Liste des Biens affectés</title>
</head>
<body>
   
   
     <livewire:bien-employe-pdf :employe="$employe">  
  
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Liste des employés</title>
</head>
<body>
   <h1>Liste des employées</h1>
   
     <livewire:liste-employes/>  
  
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Liste des Biens  d'un emplacement</title>
</head>
<body>
      <livewire:bien-emplacement-pdf :emplacement="$emplacement"> 
</body>
</html>
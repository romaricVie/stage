 
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Mouvement</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('deplacements.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Mouvement</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>
    <section class="section dashboard">
      <div>
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('deplacements', [])->html();
} elseif ($_instance->childHasBeenRendered('ztmrAVW')) {
    $componentId = $_instance->getRenderedChildComponentId('ztmrAVW');
    $componentTag = $_instance->getRenderedChildComponentTagName('ztmrAVW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ztmrAVW');
} else {
    $response = \Livewire\Livewire::mount('deplacements', []);
    $html = $response->html();
    $_instance->logRenderedChild('ztmrAVW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>     
      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/deplacements/create.blade.php ENDPATH**/ ?>
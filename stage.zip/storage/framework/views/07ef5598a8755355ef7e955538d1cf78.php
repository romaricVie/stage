<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Sous sous categorie</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('sscategories.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Sous sous categories</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <!-- Alert Messages -->

              <?php if(session('success')): ?>
                    <script type="text/javascript">
                        swal("Félicitations!","<?php echo session('success'); ?>","success",{
                            button:"OK"
                        })
                   </script>
               <?php endif; ?>
         <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sscategorie', [])->html();
} elseif ($_instance->childHasBeenRendered('p53JtW3')) {
    $componentId = $_instance->getRenderedChildComponentId('p53JtW3');
    $componentTag = $_instance->getRenderedChildComponentTagName('p53JtW3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('p53JtW3');
} else {
    $response = \Livewire\Livewire::mount('sscategorie', []);
    $html = $response->html();
    $_instance->logRenderedChild('p53JtW3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/categories/sscategorie_create.blade.php ENDPATH**/ ?>
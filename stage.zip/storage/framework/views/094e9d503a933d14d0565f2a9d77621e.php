<?php $__env->startSection('content'); ?>

<section>
 
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <h1>Statistiques</h1>
        
        <div class="row"> <!-- first lign  -->
          <div class="col-xxl-3 col-md-3">
              <div class="card text-bg-warning info-card sales-card" style="max-width: 11rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Biens</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-gem"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($biens->count()); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>

             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">

                <div class="card-body">
                  <h3 class="card-title">Categories</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-car-front-fill"></i>
                    </div>
                    <div class="">
                         <h6><?php echo e($categories); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Informatiques</h3>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-laptop"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($informatiques); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">

                <div class="card-body">
                  <h3 class="card-title">Mobiliers</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-door-open"></i>
                    </div>
                    <div class="">
                         <h6><?php echo e($mobiliers); ?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div>
        </div><!-- end first lign  -->

          <div class="row"> <!-- second lign  -->
          <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">

                <div class="card-body">
                  <h3 class="card-title">Vehicules</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-car-front-fill"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($vehicules); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Goodies</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-handbag"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e($goodies); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 13rem; height:10rem;">            
                <div class="card-body">
                  <h3 class="card-title">Electromenagers</h3>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-tv"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($electromenagers); ?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">            
                <div class="card-body">
                  <h3 class="card-title">Employés</h3>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($employes->count()); ?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div>

          </div><!-- end_second lign  -->
          <div class="row"> <!-- fird lign  -->       
            <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;" >
                <div class="card-body">
                  <h3 class="card-title">Hommes</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-gender-male"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($males); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Femmes</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-gender-female"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($females); ?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 11rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Entrepôts</h3>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-house-door"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($entrepots); ?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 12rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Emplacements</h3>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-building"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($emplacements); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
             </div>
            </div> <!-- en_fird lign  -->
            <div class="row">
              
               <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 10rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Espaces</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-distribute-vertical"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($espaces); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 12rem; height:10rem;">
                <div class="card-body">
                  <h3 class="card-title">Hors service</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-archive"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e($etat); ?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 12rem; height:10rem;">

                <div class="card-body">
                  <h3 class="card-title">Libre</h3>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-building"></i>
                    </div>
                    <div class="">
                      <h6><?php echo e($disponibilites); ?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div>
             <div class="col-xxl-3 col-md-3">
              <div class="card info-card sales-card" style="max-width: 10rem; height:10rem;">

                <div class="card-body">
                  <h5 class="card-title">Mouvements</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-arrows-move"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e($deplacements); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search', [])->html();
} elseif ($_instance->childHasBeenRendered('NRvUQ1K')) {
    $componentId = $_instance->getRenderedChildComponentId('NRvUQ1K');
    $componentTag = $_instance->getRenderedChildComponentTagName('NRvUQ1K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NRvUQ1K');
} else {
    $response = \Livewire\Livewire::mount('search', []);
    $html = $response->html();
    $_instance->logRenderedChild('NRvUQ1K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
    </section>
  </main><!-- End #main -->


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/welcome.blade.php ENDPATH**/ ?>
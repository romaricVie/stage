<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Sous categorie</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('scategories.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Sous categories</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

          <?php if(session('success')): ?>
              <script type="text/javascript">
                        swal("Félicitations!","<?php echo session('success'); ?>","success",{
                            button:"OK"
                        })
              </script>
          <?php endif; ?>
    <section class="section dashboard">
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Enregistrer une sous categorie</h5>
             <!-- Categorie Form -->
              <form  

                  class="row g-3"
                  method="POST"
                  action="<?php echo e(route('scategories.store')); ?>" 

                >
                  <?php echo csrf_field(); ?>
                  <div class="col-6">
                      <label for="inputCategorie" class="form-label">Categorie</label>
                      <select class="form-select form-select-sm" name="categorie_id"  id="inputCategorie" aria-label=".form-select-sm example" required>
                           <option value="">Choisir une categorie</option>
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div><!-- End categorie -->

                 <div class="col-6">
                    <label for="inputNanme4" class="form-label">Nom sous categorie</label>
                    <input type="text" name="name" class="form-control" id="inputNanme4" placeholder="Entrer sous categorie" required>
                </div> <!-- End sous categorie -->

                  <div class="">
                     <button type="submit" class="btn btn-success">J'enregistre une sous categorie</button>
                  </div><!-- End submit -->
              </form>
         </div>
      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/categories/scategorie_create.blade.php ENDPATH**/ ?>
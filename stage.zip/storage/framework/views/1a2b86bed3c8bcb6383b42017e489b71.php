<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Espaces</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('espaces.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Espaces</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <a href="<?php echo e(route('espaces.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter espace</button></a>

       <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('espaces', [])->html();
} elseif ($_instance->childHasBeenRendered('jzTBBfY')) {
    $componentId = $_instance->getRenderedChildComponentId('jzTBBfY');
    $componentTag = $_instance->getRenderedChildComponentTagName('jzTBBfY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jzTBBfY');
} else {
    $response = \Livewire\Livewire::mount('espaces', []);
    $html = $response->html();
    $_instance->logRenderedChild('jzTBBfY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  

    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/espace_index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Sous categorie</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('scategories.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Sous categorie</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <a href="<?php echo e(route('scategories.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter sous categorie</button></a>
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('scategories', [])->html();
} elseif ($_instance->childHasBeenRendered('zT2mm4D')) {
    $componentId = $_instance->getRenderedChildComponentId('zT2mm4D');
    $componentTag = $_instance->getRenderedChildComponentTagName('zT2mm4D');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zT2mm4D');
} else {
    $response = \Livewire\Livewire::mount('scategories', []);
    $html = $response->html();
    $_instance->logRenderedChild('zT2mm4D', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/categories/scategorie_index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Liste des Biens affectés</title>
</head>
<body>
   
   
     <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('bien-employe-pdf', ['employe' => $employe])->html();
} elseif ($_instance->childHasBeenRendered('VYypMei')) {
    $componentId = $_instance->getRenderedChildComponentId('VYypMei');
    $componentTag = $_instance->getRenderedChildComponentTagName('VYypMei');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VYypMei');
} else {
    $response = \Livewire\Livewire::mount('bien-employe-pdf', ['employe' => $employe]);
    $html = $response->html();
    $_instance->logRenderedChild('VYypMei', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
  
</body>
</html><?php /**PATH C:\web\patrimoine\stage\resources\views/employes/biens_pdf.blade.php ENDPATH**/ ?>
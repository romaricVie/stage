<div>
    

    <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des employés(<?php echo e($employes->count()); ?>)</h5>
            <div class="row">
                 <div class="col-6">
                    <input type="text" name="employe" wire:model="query"  class="form-control" placeholder="Rechercher un employé">
               </div> <!-- End search -->
                <div class="col-6">
                     Afficher
                      <select wire:model.lazy="perPage" id="Per-page" class="">
                           <?php for($i=5; $i <= 25; $i += 5): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                          <?php endfor; ?>
                      </select>
                      par page
                   </div>
            </div>
             
               
             <!-- employe table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                       <th scope="col">#</th>
                       <th scope="col">Nom et prenom</th>
                       <th scope="col">Fonction</th>
                       <th scope="col">Contacts</th>
                       <th scope="col">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $employes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($employe->id); ?></th>
                        <td>
                          <a href="<?php echo e(route('employes.infos', ['employe' => $employe->id])); ?>"><?php echo e($employe->name."  ".$employe->firstname); ?></a>
                        </td>
                         <td><?php echo e($employe->fonction); ?></td>
                         <td><?php echo e($employe->contact); ?></td>
                        <td>
                           <a href="<?php echo e(route('employes.show', ['employe' => $employe->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a> 
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
           <?php echo e($employes->links()); ?>

         </div>
          <div class="d-flex justify-content-end m-4">
            <a class="btn btn-outline-primary" href="<?php echo e(route('employes.pdf')); ?>"><i class="bi bi-printer-fill"></i> Imprimer</a>
        </div>
      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/employe.blade.php ENDPATH**/ ?>
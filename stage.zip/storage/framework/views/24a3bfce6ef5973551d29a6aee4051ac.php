
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Mouvement details </h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('deplacements.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Mouvement</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <form  

              action="<?php echo e(route('deplacements.destroy',$deplacement)); ?>"
              method="POST"
              onsubmit ="return confirm('Etre vous sûr de vouloir supprimer cet mouvement ?');"
              class="d-inline" 
        >
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
           <button type="submit" class="btn btn-outline-danger btn-sm m-2"><i class="bi bi-write"></i>Supprimer</button>
      </form>
      
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Détail du mouvement</h5>
             <!-- Bien table -->
              <p>
                 <span class="fw-bold">Désignation:</span>
                     <a href="<?php echo e(route('biens.show',['bien' => $deplacement->bien->id])); ?>"><?php echo e($deplacement->bien->name); ?></a>
               </p>
              <p>
                 <span class="fw-bold">Identifiant:</span>
                   <span class="badge rounded-pill text-bg-success"><?php echo e($deplacement->bien->etiquette); ?></span> 
              </p>
               <p>
                   <span class="fw-bold">Code:</span> <?php echo e($deplacement->bien->code); ?>

               </p>
               <p>
                 <span class="fw-bold">Entrepot:</span>
                    <a href="<?php echo e(route('entrepots.show',['entrepot'=>$deplacement->entrepot->id])); ?>"><?php echo e($deplacement->entrepot->name); ?></a>
               </p>
               <p>
                  <span class="fw-bold">Emplacement:</span> 
                    <a href="<?php echo e(route('emplacements.show',['emplacement' => $deplacement->emplacement->id])); ?>"><?php echo e($deplacement->emplacement->name); ?></a>
                </p>
               <p><span class="fw-bold">Espace:</span>
                  <a href="<?php echo e(route('espaces.show',['espace'=>$deplacement->espace->id])); ?>"><?php echo e($deplacement->espace->name); ?></a>
               </p>
               <p><span class="fw-bold">Entité :</span>
                     <a href="<?php echo e(route('entites.show',['entite'=>$deplacement->entite->id])); ?>"><?php echo e($deplacement->entrepot->name); ?>

                 </a>
              </p>
              <p><span class="fw-bold">Motif deplacement:</span> <?php echo e($deplacement->motif_deplacement); ?></p>
              <p><span class="fw-bold">Description:</span> <?php echo e($deplacement->description); ?></p>
              <p><span class="fw-bold">Deplacer le :</span> <?php echo e($deplacement->created_at); ?></p>

         </div>
      </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/deplacements/show.blade.php ENDPATH**/ ?>
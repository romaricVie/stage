<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Bien</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('biens.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Bien</li>
          <li class="breadcrumb-item active">Ajouté par <?php echo e($bien->user->name.' '.$bien->user->firstname); ?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
             <!-- Bien detail -->
      
      <a href="<?php echo e(route('biens.edit',['bien' => $bien->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm m-2 d-inline"><i class="bi bi-write"></i>Modifier</button></a>
      <form  

              action="<?php echo e(route('biens.destroy',$bien)); ?>"
              method="POST"
              onsubmit ="return confirm('Etre vous sur de vouloir supprimer ce bien?');"
              class="d-inline" 
        >
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
           <button type="submit" class="btn btn-outline-danger btn-sm m-2"><i class="bi bi-write"></i>Supprimer</button></a>
      </form>
      

      <div class="card">
         <div class="card-body">
             <!-- Bien table -->
             <?php if($bien->image): ?>
              <h5 class="card-title">image du bien</h5>
                 <img src="<?php echo e(asset('storage/'.$bien->image)); ?>" alt="img" title="image" class="img-fluid" style="width:450px; height:450px"  >
              <?php endif; ?>
              <h5 class="card-title">Informations sur le bien</h5>
              <div>
                  <span class="fw-bold">Nom :</span> <?php echo e($bien->name); ?><br>
                  <span class="fw-bold">Etiquette :</span> <span class="badge rounded-pill text-bg-primary"><?php echo e($bien->etiquette); ?></span><br>
                  <span class="fw-bold">Marque :</span> <?php echo e($bien->marque  ?? 'non-defini'); ?><br>
                  <span class="fw-bold">Prix :</span> <?php echo e($bien->price ?? 'non-defini'); ?><br>
                  <span class="fw-bold">couleur :</span> <?php echo e($bien->couleur ?? 'non-definie'); ?><br>
                  <span class="fw-bold">Disponibilité :</span> <span class="badge rounded-pill text-bg-<?= $bien->disponibilite== 'occupe' ? 'warning' : 'success'?>"><?php echo e($bien->disponibilite); ?></span> <br>
                  <span class="fw-bold">Etat :</span>
                          <span class="badge rounded-pill text-bg-<?= $bien->etat== 'bon' ? 'info' : 'danger'?>"> <?php echo e($bien->etat); ?></span><br>
                  <span class="fw-bold">Achat :</span> <?php echo e($bien->day); ?>/<?php echo e($bien->month); ?>/<?php echo e($bien->year); ?><br>
                  <span class="fw-bold">Affecté à :</span>
                        <?php if($bien->affectations->count()>0): ?>
                            <ol>
                             <?php $__currentLoopData = $bien->affectations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affectation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('employes.show', ['employe' => $affectation->employe->id])); ?>"> <?php echo e($affectation->employe->name); ?> <?php echo e($affectation->employe->firstname); ?></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </ol>
                               <?php else: ?>
                                 <span>Pas encors affecté</span><br>
                              <?php endif; ?>
                  <span class="fw-bold">Code :</span> <?php echo e($bien->code ?? 'non-defini'); ?><br>
                  <span class="fw-bold">Categorie :</span> 
                    <a href="<?php echo e(route('categories.show',['categorie'=>$bien->categorie->id])); ?>">
                        <?php echo e($bien->categorie->name); ?></a><br>
                  <span class="fw-bold">Sous Categorie :</span>
                     <a href="<?php echo e(route('scategories.show',['scategorie'=>$bien->scategorie->id])); ?>">
                     <?php echo e($bien->scategorie->name); ?></a><br>
                  <span class="fw-bold">Sous sous categorie :</span> 
                     <?php if($bien->sscategorie->name): ?>
                        <a href="<?php echo e(route('sscategories.show',['sscategorie'=>$bien->sscategorie->id])); ?>"><?php echo e($bien->sscategorie->name); ?></a><br>
                      <?php endif; ?>
                  <span class="fw-bold">disque_dur :</span> <?php echo e($bien->disque_dur ?? 'non-defini'); ?><br>
                  <span class="fw-bold">processeur :</span> <?php echo e($bien->processeur ?? 'non-defini'); ?><br>
                  <span class="fw-bold">Ram :</span> <?php echo e($bien->ram ?? 'non-definie'); ?><br>
                  <span class="fw-bold">Generation :</span> <?php echo e($bien->generation ?? 'non-defini'); ?><br>
                  <span class="fw-bold">Longeur :</span> <?php echo e($bien->longueur ?? 'non-definie'); ?><br>
                  <span class="fw-bold">Largeur :</span> <?php echo e($bien->largeur ?? 'non-definie'); ?><br>
                  <span class="fw-bold">Hauteur :</span> <?php echo e($bien->hauteur ?? 'non-definie'); ?><br>
                   <?php if($bien->nbre_battant): ?>
                      <span class="fw-bold">Nombre de battants :</span> <?php echo e($bien->nbre_battant); ?><br>
                  <?php endif; ?>
                  <span class="fw-bold">poids :</span> <?php echo e($bien->poids ?? 'non-defini'); ?><br>
                  <span class="fw-bold">immatriculation :</span> <?php echo e($bien->immatriculation ?? 'non-defini'); ?><br>
                  <?php if($bien->entrepot): ?>
                    <span class="fw-bold">Entrepots:</span>
                      <a href="<?php echo e(route('entrepots.show',['entrepot'=>$bien->entrepot->id])); ?>"><?php echo e($bien->entrepot->name); ?></a><br>
                    <?php else: ?>
                     <span>non-defini</span><br>
                  <?php endif; ?>
                 <span class="fw-bold">Emplacement :</span>
                    <?php if($bien->emplacement): ?>
                      <a href="<?php echo e(route('emplacements.show',['emplacement' => $bien->emplacement->id])); ?>"><?php echo e($bien->emplacement->name); ?></a><br>
                  <?php else: ?>
                     <span>non-defini</span><br>
                  <?php endif; ?>
                  <span class="fw-bold">Espace :</span> 
                  <?php if($bien->espace): ?>
                          <a href="<?php echo e(route('espaces.show',['espace'=>$bien->espace->id])); ?>"><?php echo e($bien->espace->name); ?></a><br>
                   <?php else: ?>
                    <span>non-defini</span><br>
                   <?php endif; ?>

                  <span class="fw-bold">Entité :</span> 
                   <?php if($bien->entite): ?>
                       <a href="<?php echo e(route('entites.show',['entite'=>$bien->entite->id])); ?>"><?php echo e($bien->entite->name); ?></a><br>
                   <?php else: ?>
                     <span>non-defini</span><br>
                   <?php endif; ?>
                   <?php if($bien->puissance): ?>
                      <span class="fw-bold">Puissance :</span> <?php echo e($bien->puissance); ?><br>
                   <?php endif; ?>
                   <?php if($bien->matiere): ?>
                      <span class="fw-bold">matiere :</span> <?php echo e($bien->matiere); ?><br>
                  <?php endif; ?>
                    <?php if($bien->place): ?>
                      <span class="fw-bold">Places assises :</span> <?php echo e($bien->place); ?><br>
                  <?php endif; ?>
                    <?php if($bien->energie): ?>
                     <span class="fw-bold">Energie :</span> <?php echo e($bien->energie); ?><br>
                    <?php endif; ?>

                  <span class="fw-bold">Quantité :</span> <?php echo e($bien->quantite ?? 'non-definie'); ?><br>

                 <?php if($bien->expiration): ?>
                     <span class="fw-bold">Date d'expiration :</span> <?php echo e($bien->expiration); ?><br>
                  <?php endif; ?>
                   <span class="fw-bold">Nom fournisseur :</span> <?php echo e($bien->fournisseur_name ?? 'non-defini'); ?><br>
                   <span class="fw-bold">Contact fournisseur :</span> <?php echo e($bien->fournisseur_tel ?? 'non-defini'); ?><br>
                   <?php if($bien->autres): ?>
                     <span class="fw-bold">autres :</span> <?php echo e($bien->autres ?? 'non-defini'); ?><br>
                  <?php endif; ?>
                  <span class="fw-bold">Mouvements :</span>
                        <?php if($bien->deplacements->count()>0): ?>
                            <ol>
                             <?php $__currentLoopData = $bien->deplacements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deplacement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('entrepots.show',['entrepot'=>$deplacement->entrepot->id])); ?>"> <?php echo e($deplacement->entrepot->name); ?> </a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </ol>
                               <?php else: ?>
                                 <span>Pas encors en mouvement</span><br>
                              <?php endif; ?>

                  <span class="fw-bold">Enregistré le :</span> <?php echo e($bien->created_at); ?><br>
              </div>  
         </div>
      </div>
      <!-- QR-Code -->
       <div class="col-xl-4">
            <div class="card">
              <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                <?php echo e(QrCode::format('svg')->size(200)->generate($bien->entrepot->name.' - '.$bien->emplacement->name.' - '.$bien->espace->name." Id: ".$bien->etiquette)); ?>

              </div>
            </div>
          </div>


    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/biens/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Employés</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('employes.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Employés</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <!-- Alert Messages -->

          <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>
    <section class="section dashboard">
      <div class="card">
         <div class="card-body">
            <h5 class="card-title text-center">Enregistrer un employé</h5>
             <!-- Employes Form -->
              <form  
                    class="row g-3"
                    method="POST"
                    action="<?php echo e(route('employes.store')); ?>" 
              >
              <?php echo csrf_field(); ?>
                  <div class="col-6">
                      <label for="inputNanme4" class="form-label">Nom <span class="text-danger"> *</span></label>
                      <input type="text" name="name"  class="form-control" id="inputNanme4" placeholder="Entrer nom" required>
                  </div>
                  <div class="col-6">
                      <label for="inputNanme9" class="form-label">Prenoms <span class="text-danger"> *</span></label>
                      <input type="text" name="firstname" class="form-control" id="inputNanme9" placeholder="Entrer prenoms" required>
                  </div>
                   <div class="col-6">
                      <label for="inputNanme7" class="form-label">Fonction <span class="text-danger"> *</span></label>
                      <input type="text" name="fonction" class="form-control" id="inputNanme7" placeholder="Entrer la fonction" required>
                  </div>
                   <div class="col-6">
                    <label for="inputEntite" class="form-label">Entité <span class="text-danger"> *</span></label>
                    <select name="entite_id" class="form-select form-select-sm" id="inputEntite" aria-label=".form-select-sm example">
                         <option selected>Choisir une entité</option>
                         <?php $__currentLoopData = $entites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($entite->id); ?>"><?php echo e($entite->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                  <div class="col-6">
                      <label for="inputNanme6"  class="form-label">Email <span class="text-danger"> *</span></label>
                      <input type="email" name="email" class="form-control" id="inputNanme6" placeholder="Entrer email" required>
                  </div>
                 

                  <div class="col-6">
                      <label for="inputNanme8" class="form-label">Contact <span class="text-danger"> *</span></label>
                      <input type="text" name="contact" class="form-control" id="inputNanme8" placeholder="Entrer contact" required>
                  </div>
                   <div class="col-6">
                      <label for="inputNanme10" class="form-label">Numéro flotte</label>
                      <input type="text" name="flotte" class="form-control" id="inputNanme10" placeholder="Entrer numéro flotte" >
                  </div>
                   <div class="col-6">
                      <label for="inputNanme01" class="form-label">Ligne fixe</label>
                      <input type="text" name="fixe" class="form-control" id="inputNanme01" placeholder="Entrer le fixe">
                  </div>
                 
                  <div class="col-6">
                     <label for="" class="form-label">Statut <span class="text-danger"> *</span></label>
                       <div class="form-check">
                           <input class="form-check-input" type="radio" name="statut" value="actif" id="flexRadioDefault2">
                           <label class="form-check-label" for="flexRadioDefault2">
                           Actif
                          </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="statut" value="inactif" id="flexRadioDefault3">
                           <label class="form-check-label" for="flexRadioDefault3">
                           Inactif
                          </label>
                       </div>
                </div>

                <div class="col-6">
                     <label for="" class="form-label">Type de contrat <span class="text-danger"> *</span></label>
                       <div class="form-check">
                           <input class="form-check-input" type="radio" name="contrat" value="cdi" id="flexRadioDefault1">
                           <label class="form-check-label" for="flexRadioDefault1">
                           CDI
                          </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="contrat" value="cdd" id="flexRadioDefault4">
                           <label class="form-check-label" for="flexRadioDefault4">
                           CDD
                          </label>
                       </div>
                </div>
                <div class="col-6"><!-- New --> 
                     <label for="" class="form-label">Sexe <span class="text-danger"> *</span></label>
                       <div class="form-check">
                           <input class="form-check-input" type="radio" name="sexe" value="male" id="flexRadioDefault01" required>
                           <label class="form-check-label" for="flexRadioDefault01">
                           Homme
                          </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="sexe" value="female" id="flexRadioDefault04" required>
                           <label class="form-check-label" for="flexRadioDefault04">
                           Femme
                          </label>
                       </div>
                </div>
                <div class="col-6 form-floating">
                        <textarea class="form-control" name="autres" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                        <label for="floatingTextarea">Autres infos</label>
                </div><!--End autre--> 
                <div class="text-center">
                     <button type="submit" class="btn btn-success">J'enregistre un employé</button>
                </div>
            </form>
         </div>
      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/employes/create.blade.php ENDPATH**/ ?>
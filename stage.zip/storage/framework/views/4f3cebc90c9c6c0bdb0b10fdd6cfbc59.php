<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Entrepôt</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('entrepots.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active"><?php echo e($entrepot->name); ?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des biens de l'entrepôt <?php echo e($entrepot->name); ?> (<?php echo e($entrepot->biens->count()); ?>)</h5>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#Identifiant</th>
                      <th scope="col">Code</th>
                      <th scope="col">Désignation</th>
                      <th scope="col">Etat</th>
                      <th scope="col">Disponibilité</th>
                      <th scope="col">Categorie</th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $entrepot->biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><span class="badge rounded-pill text-bg-primary"><?php echo e($bien->etiquette); ?></span></th>
                        <td><?php echo e($bien->code); ?></td>
                        <td><a href="<?php echo e(route('biens.show',['bien'=>$bien->id])); ?>"><?php echo e($bien->name); ?></a></td>
                        <td><?php echo e($bien->etat); ?></td>
                        <td><span class="badge rounded-pill text-bg-<?= $bien->disponibilite== 'occupe' ? 'warning' : 'success'?>"><?php echo e($bien->disponibilite); ?></span></td>
                        <td><?php echo e($bien->categorie->name); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
            <div class="d-flex justify-content-end m-4">
                <a class="btn btn-outline-primary" href="<?php echo e(route('entrepots.biens.pdf',$entrepot)); ?>"><i class="bi bi-printer-fill"></i> Imprimer</a>
           </div>
           <h5 class="card-title">Informations de l'entrepot <?php echo e($entrepot->name); ?></h5>
           <!-- Bien table -->
              <div>
                  <p><span class="fw-bold">Pays :</span> <?php echo e($entrepot->pays ?? 'Non defini'); ?></p>
                   <p><span class="fw-bold">Pays :</span> <?php echo e($entrepot->ville ?? 'Non defini'); ?></p>
                  <p><span class="fw-bold">Adresse geographique :</span> <?php echo e($entrepot->adresse_geographique); ?></p>
                  <p><span class="fw-bold">batiment :</span> <?php echo e($entrepot->batiment ?? 'Non defini'); ?></p>
                  <p><span class="fw-bold">Nom étage :</span> <?php echo e($entrepot->etage ?? 'Non defini'); ?></p>
                  <p><span class="fw-bold">Nombre Piece :</span> <?php echo e($entrepot->piece ?? 'Non defini'); ?></p>
                  <p><span class="fw-bold">Superficie :</span> <?php echo e($entrepot->superficie ?? 'Non defini'); ?></p>
                  <p><span class="fw-bold">Nombre de parking :</span> <?php echo e($entrepot->parking ?? 'Non defini'); ?></p>
                  <p><span class="fw-bold">Description :</span> <?php echo e($entrepot->description ?? 'Non defini'); ?><p>
                 
              </div>  
        </div>

      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/show.blade.php ENDPATH**/ ?>
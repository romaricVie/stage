<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Sous sous categorie</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Sous sous categorie</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <a href="<?php echo e(route('sscategories.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter une sous sous categorie</button></a>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sscategories', [])->html();
} elseif ($_instance->childHasBeenRendered('orURxY5')) {
    $componentId = $_instance->getRenderedChildComponentId('orURxY5');
    $componentTag = $_instance->getRenderedChildComponentTagName('orURxY5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('orURxY5');
} else {
    $response = \Livewire\Livewire::mount('sscategories', []);
    $html = $response->html();
    $_instance->logRenderedChild('orURxY5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/categories/sscategorie_index.blade.php ENDPATH**/ ?>
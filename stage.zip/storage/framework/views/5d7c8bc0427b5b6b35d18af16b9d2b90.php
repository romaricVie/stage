<div>
    

     <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des affectations</h5>
             
             <div class="row">
                 <div class="col-6">
                    <input type="text" name="etiquette" wire:model="query"  class="form-control" placeholder="Entrer etiquette">
                </div> <!-- End search -->
                <div class="col-6">
                     Afficher
                      <select wire:model.lazy="perPage" id="Per-page" class="">
                           <?php for($i=25; $i <= 100; $i += 25): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                          <?php endfor; ?>
                      </select>
                      par page
              </div>
            </div>
               <!-- affectation table -->
              <table class="table table-hover">
                  <thead>
                    <tr>
                       <th scope="col">#Identifiant</th>
                       <th scope="col">Code</th>
                       <th scope="col">Nom employé</th>
                       <th scope="col">Designation</th>
                       <th scope="col">Action</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $affectations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affectation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($affectation->bien->etiquette); ?></th>
                        <td><?php echo e($affectation->bien->code); ?></td>
                        <td><a href="<?php echo e(route('employes.show', ['employe' => $affectation->employe->id])); ?>"><?php echo e($affectation->employe->name.' '.$affectation->employe->firstname); ?></a></td>
                        <td><a href="<?php echo e(route('biens.show',['bien'=>$affectation->bien->id])); ?>"><?php echo e($affectation->bien->name); ?></a></td>
                        <td><a href="<?php echo e(route('affectations.show', ['affectation' => $affectation->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
          <?php echo e($affectations->links()); ?>

      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/affectations.blade.php ENDPATH**/ ?>
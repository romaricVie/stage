<div>
    

    <div class="card">
         <div class="card-body">
            <h5 class="card-title">Enregistrer une sous sous categorie</h5>
             <!-- Categorie Form -->
              <form  

                  class="row g-3"
                  method="POST"
                  action="<?php echo e(route('sscategories.store')); ?>" 

                 >
                  <?php echo csrf_field(); ?>
                  <div class="col-6">
                      <label for="inputCategorie" class="form-label">Categorie <span class="text-danger"> *</span></label>
                      <select

                            name="categorie_id" 
                            class="form-select form-select-sm"
                            id="inputCategorie"
                            aria-label=".form-select-sm example"
                            wire:model.lazy="query"
                            required
                           >
                           <option value="" selected>Choisir une categorie</option>
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>

                  </div><!-- End categorie -->
                  <div class="col-6">
                      <label for="inputScategorie" class="form-label">Sous Categorie <span class="text-danger"> *</span></label>
                      <select name="scategorie_id" class="form-select form-select-sm" id="inputScategorie" aria-label=".form-select-sm example" required>
                           <option value="" selected>Choisir sous categorie</option>
                           <?php $__currentLoopData = $scategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scategorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($scategorie->id); ?>"><?php echo e($scategorie->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div><!-- End sous categorie -->

                 <div class="col-6">
                    <label for="inputNanme5" class="form-label">Nom sous sous categorie <span class="text-danger"> *</span></label>
                    <input type="text" name="name" class="form-control" id="inputNanme5" placeholder="Entrer sous categorie" required>
                </div> <!-- End sous categorie -->

                  <div class="">
                     <button type="submit" class="btn btn-success">J'enregistre une sous sous categorie</button>
                  </div><!-- End submit -->
              </form>
         </div>
      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/sscategorie.blade.php ENDPATH**/ ?>
<div>
    
    
      <div class="card">
         <div class="card-body">
            <h1 class="card-title">Liste des biens de l'entrepôt <?php echo e($entrepot->name); ?></h1>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#Identifiant</th>
                      <th scope="col">Désignation</th>
                      <th scope="col">Etat</th>
                      <th scope="col">Disponibilité</th>
                      <th scope="col">Categorie</th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $entrepot->biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($bien->etiquette); ?></th>
                        <td><?php echo e($bien->name); ?></td>
                        <td><?php echo e($bien->etat); ?></td>
                        <td><?php echo e($bien->disponibilite); ?></td>
                        <td><?php echo e($bien->categorie->name); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
        </div>
      </div>

   

</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/bien-entrepot-pdf.blade.php ENDPATH**/ ?>
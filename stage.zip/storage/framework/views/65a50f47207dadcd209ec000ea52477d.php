<div>
    
     <div class="row">
            <div class="col-6">
                 <input wire:model="query" wire:keyup.debounce="filter" type="text" name="bien"  class="form-control" placeholder="Rechercher un bien">
            </div>
            <div class="col-6">
                  <select wire:model="categorie_id"  wire:change="filter"class="form-select">

                            <option value="">Choisir la categorie</option>
                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                      </select>
                   </div>
          </div>

</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/filter-pots.blade.php ENDPATH**/ ?>
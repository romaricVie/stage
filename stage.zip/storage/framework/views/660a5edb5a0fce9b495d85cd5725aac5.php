<div>
    


     <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des biens (<?php echo e($biens->count()); ?>)</h5>
           <!--  <div class="row">
                 <div class="col-6">
                    <input type="text" name="bien" wire:model="query"  class="form-control" placeholder="Rechercher un bien">
               </div>-->

            </div> 
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#Identifiant</th>
                      <th scope="col">Code</th>
                      <th scope="col">Désignation</th>
                      <th scope="col">Etat</th>
                      <th scope="col">Disponibilité</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><span class="badge rounded-pill text-bg-primary"><?php echo e($bien->etiquette); ?></span></th>
                         <td><?php echo e($bien->code ?? 'Non defini'); ?></td>
                         <td><?php echo e($bien->name); ?></td>
                        <td>
                            <span class="badge rounded-pill text-bg-<?= $bien->etat== 'bon' ? 'info' : 'danger'?>"><?php echo e($bien->etat); ?></span>
                        </td>
                         <td><span class="badge rounded-pill text-bg-<?= $bien->disponibilite== 'occupe' ? 'warning' : 'success'?>"><?php echo e($bien->disponibilite); ?></span></td>
                        <td>
                           <a href="<?php echo e(route('biens.show', ['bien' => $bien->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                       </td>
                      </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/biens.blade.php ENDPATH**/ ?>
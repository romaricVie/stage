<div>
    
    <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des sous categories</h5>

             <div class="row">
                  <div class="col-6">
                       <input type="text" name="scategorie" wire:model="query"  class="form-control" placeholder="Rechercher une sous categorie">
                   </div> <!-- End search -->
                    <div class="col-6">
                         Afficher
                        <select wire:model.lazy="perPage" id="Per-page" class="">
                               <?php for($i=5; $i <= 25; $i += 5): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                              <?php endfor; ?>
                         </select>
                          par page
                       </div>
            </div>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Désignation sous categorie</th>
                      <th scope="col">Categorie</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $scategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scategorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($scategorie->id); ?></th>
                        <td><?php echo e($scategorie->name); ?></td>
                        <td><?php echo e($scategorie->categorie->name); ?></td>
                         <td>
                           <a href="<?php echo e(route('scategories.show',['scategorie'=>$scategorie->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                       </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
           <?php echo e($scategories->links()); ?>

      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/scategories.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Formulaire d'enregistrement</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('biens.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Biens</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

     <section class="section dashboard">

          <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('bien-create', [])->html();
} elseif ($_instance->childHasBeenRendered('VcXQRVP')) {
    $componentId = $_instance->getRenderedChildComponentId('VcXQRVP');
    $componentTag = $_instance->getRenderedChildComponentTagName('VcXQRVP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VcXQRVP');
} else {
    $response = \Livewire\Livewire::mount('bien-create', []);
    $html = $response->html();
    $_instance->logRenderedChild('VcXQRVP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
    </section>
    
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/biens/create.blade.php ENDPATH**/ ?>
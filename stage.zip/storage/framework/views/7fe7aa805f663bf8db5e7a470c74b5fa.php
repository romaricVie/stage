<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Affectations</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('affectations.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Affectations</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <a href="<?php echo e(route('affectations.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Enregistrer une affectation</button></a>

           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('affectations', [])->html();
} elseif ($_instance->childHasBeenRendered('OD4IIZl')) {
    $componentId = $_instance->getRenderedChildComponentId('OD4IIZl');
    $componentTag = $_instance->getRenderedChildComponentTagName('OD4IIZl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OD4IIZl');
} else {
    $response = \Livewire\Livewire::mount('affectations', []);
    $html = $response->html();
    $_instance->logRenderedChild('OD4IIZl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/affectations/index.blade.php ENDPATH**/ ?>
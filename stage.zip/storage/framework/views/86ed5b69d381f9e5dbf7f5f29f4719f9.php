<div>
    
     <div class="card">
         <div class="card-body">
            <h1 class="card-title">Liste des biens affectés à <?php echo e($employe->name." ".$employe->firstname); ?></h1>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                       <th scope="col">#Indentifiant</th>
                       <th scope="col">Désignation</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $employe->affectations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affectation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($affectation->bien->etiquette); ?></th>
                        <td><?php echo e($affectation->bien->name); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
      </div>
  

</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/bien-employe-pdf.blade.php ENDPATH**/ ?>
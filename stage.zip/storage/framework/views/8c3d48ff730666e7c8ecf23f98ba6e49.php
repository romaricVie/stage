
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Mouvements</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('deplacements.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Mouvement</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
     </div><!-- End Page Title -->
    <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>
    <section class="section dashboard">
       <a href="<?php echo e(route('deplacements.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Enregistrer un mouvement</button></a>

          <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des mouvements</h5>
             
               <!-- affectation table -->
              <table class="table table-hover">
                  <thead>
                    <tr>
                       <th scope="col">#Identifiant</th>
                       <th scope="col">Code</th>
                       <th scope="col">Désignation</th>
                       <th scope="col">Entrepôt</th>
                       <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $deplacements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deplacement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($deplacement->bien->etiquette); ?></th>
                         <td><?php echo e($deplacement->bien->code); ?></td>
                          <td>
                              <a href="<?php echo e(route('biens.show',['bien'=>$deplacement->bien->id])); ?>"><?php echo e($deplacement->bien->name); ?></a>
                            </td>
                            <td>
                              <a href="<?php echo e(route('entrepots.show',['entrepot'=>$deplacement->entrepot->id])); ?>"><?php echo e($deplacement->entrepot->name); ?></a>
                            </td>
                            <td>
                               <a href="<?php echo e(route('deplacements.show', ['deplacement' => $deplacement->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                           </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
           <?php echo e($deplacements->links()); ?>

         </div> 
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/deplacements/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Réparations</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/">Home</a></li>
          <li class="breadcrumb-item active">Réparations</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <a href="<?php echo e(route('reparations.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Enregistrer une réparation</button></a>
      
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('reparations', [])->html();
} elseif ($_instance->childHasBeenRendered('YeqHV2e')) {
    $componentId = $_instance->getRenderedChildComponentId('YeqHV2e');
    $componentTag = $_instance->getRenderedChildComponentTagName('YeqHV2e');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YeqHV2e');
} else {
    $response = \Livewire\Livewire::mount('reparations', []);
    $html = $response->html();
    $_instance->logRenderedChild('YeqHV2e', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/reparations/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Entité</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
          <li class="breadcrumb-item active"><?php echo e($entite->name); ?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des biens de l'entité <?php echo e($entite->name); ?></h5>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Désignation</th>
                      <th scope="col">Etat</th>
                      <th scope="col">Disponibilité</th>
                      <th scope="col">Entrepôts</th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $entite->biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($bien->id); ?></th>
                        <td> <a href="<?php echo e(route('biens.show',['bien'=>$bien->id])); ?>"><?php echo e($bien->name); ?></a></td>
                        <td><span class="badge rounded-pill text-bg-<?= $bien->etat== 'bon' ? 'info' : 'danger'?>"> <?php echo e($bien->etat); ?></span></td>
                        <td> <span class="badge rounded-pill text-bg-<?= $bien->disponibilite== 'occupe' ? 'warning' : 'success'?>"><?php echo e($bien->disponibilite); ?></span></td>
                        <td><?php echo e($bien->entrepot->name); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>  
          </table> 
           <h5 class="card-title">Informations de l'entité <?php echo e($entite->name); ?></h5>
                <div>
                    <p><span class="fw-bold">Pays :</span> <?php echo e($entite->pays); ?></p>
                    <p><span class="fw-bold">Ville :</span> <?php echo e($entite->ville); ?></p>
              </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entites/show.blade.php ENDPATH**/ ?>
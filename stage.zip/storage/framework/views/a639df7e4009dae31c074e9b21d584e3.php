<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Biens</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('biens.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Biens</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>

    <section class="section dashboard">
       <a href="<?php echo e(route('biens.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter un bien</button></a>
       
       <!-- Filtre -->
        <div class="mb-2">
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('filter-pots', [])->html();
} elseif ($_instance->childHasBeenRendered('LaDqHWZ')) {
    $componentId = $_instance->getRenderedChildComponentId('LaDqHWZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('LaDqHWZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LaDqHWZ');
} else {
    $response = \Livewire\Livewire::mount('filter-pots', []);
    $html = $response->html();
    $_instance->logRenderedChild('LaDqHWZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <!-- Table-->
        <div class="">
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('biens', [])->html();
} elseif ($_instance->childHasBeenRendered('FB597OH')) {
    $componentId = $_instance->getRenderedChildComponentId('FB597OH');
    $componentTag = $_instance->getRenderedChildComponentTagName('FB597OH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FB597OH');
} else {
    $response = \Livewire\Livewire::mount('biens', []);
    $html = $response->html();
    $_instance->logRenderedChild('FB597OH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
        </div>
        
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/biens/index.blade.php ENDPATH**/ ?>
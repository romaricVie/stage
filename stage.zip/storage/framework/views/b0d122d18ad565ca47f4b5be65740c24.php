<div>
    

    <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des espaces</h5>
              <div class="row">
                 <div class="col-6">
                    <input type="text" name="espace" wire:model="query"  class="form-control" placeholder="Rechercher un espace">
                </div> <!-- End search -->
                <div class="col-6">
                     Afficher
                      <select wire:model.lazy="perPage" id="Per-page" class="">
                           <?php for($i=5; $i <= 25; $i += 5): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                          <?php endfor; ?>
                      </select>
                      par page
              </div>
            </div>
             <!-- espace table -->
              <table class="table table-hover">
                  <thead>
                    <tr>
                       <th scope="col">#</th>
                       <th scope="col">Désignation espace</th>
                       <th scope="col">Emplacement</th>
                       <th scope="col">Entrepôt</th>
                       <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $espaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $espace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($espace->id); ?></th>
                        <td><?php echo e($espace->name); ?></td>
                        <td><?php echo e($espace->emplacement->name); ?></td>
                        <td><?php echo e($espace->entrepot->name); ?></td>
                        <td>
                           <a href="<?php echo e(route('espaces.show', ['espace' => $espace->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                       </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
           <?php echo e($espaces->links()); ?>

      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/espaces.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Espace</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('espaces.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active"><?php echo e($espace->name); ?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       
      <div class="card">
         <div class="card-body">
            <h1 class="card-title">Liste des biens de l'espace <?php echo e($espace->name); ?> (<?php echo e($espace->biens->count()); ?>)</h1>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#Identifiant</th>
                      <th scope="col">Code</th>
                      <th scope="col">Désignation</th>
                      <th scope="col">Etat</th>
                      <th scope="col">Disponibilité</th>
                      <th scope="col">Categorie</th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $espace->biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><span class="badge rounded-pill text-bg-primary"><?php echo e($bien->etiquette); ?></span></th>
                        <td><?php echo e($bien->code); ?></td>
                        <td><a href="<?php echo e(route('biens.show',['bien'=>$bien->id])); ?>"><?php echo e($bien->name); ?></a></td>
                        <td><?php echo e($bien->etat); ?></td>
                        <td><span class="badge rounded-pill text-bg-<?= $bien->disponibilite== 'occupe' ? 'warning' : 'success'?>"><?php echo e($bien->disponibilite); ?></span></td>
                        <td><?php echo e($bien->categorie->name); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
         <div class="d-flex justify-content-end m-4">
            <a class="btn btn-outline-primary" href="<?php echo e(route('espaces.bien.pdf',$espace)); ?>"><i class="bi bi-printer-fill"></i> Imprimer</a>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/espace_show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Emplacement</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('emplacements.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Emplacement</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    
     <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>

    <section class="section dashboard">
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Enregistrer un emplacement</h5>
             <!-- Categorie Form -->
              <form  

                  class="row g-3"
                  method="POST"
                  action="<?php echo e(route('emplacements.store')); ?>" 
                  >
                   <?php echo csrf_field(); ?>
                  <div class="col-6">
                      <label for="inputCategorie" class="form-label">Entrepôt <span class="text-danger"> *</span></label>
                      <select name="entrepot_id" class="form-select form-select-sm" id="inputCategorie" aria-label=".form-select-sm example">
                           <option selected>Choisir un entrepot</option>
                           <?php $__currentLoopData = $entrepots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrepot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($entrepot->id); ?>"><?php echo e($entrepot->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div><!-- End emplacement -->

                 <div class="col-6">
                    <label for="inputNanme4" class="form-label">Nom emplacement <span class="text-danger"> *</span></label>
                    <input type="text" name="name" class="form-control" id="inputNanme4" placeholder="Entrer emplacement" required>
                </div> <!-- End emplacement -->

                 <div class="col-6 form-floating">
                    <textarea class="form-control" name="description" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                      <label for="floatingTextarea">Description</label>
                </div>

                  <div class="">
                     <button type="submit" class="btn btn-success">J'enregistre un emplacement</button>
                  </div><!-- End submit -->
              </form>
         </div>
      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/emplacement_create.blade.php ENDPATH**/ ?>
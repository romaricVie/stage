<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Liste employés</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('employes.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Employé</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>
    <section class="section dashboard">
       <div>
           <a href="<?php echo e(route('employes.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter employé</button></a>
       </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('employe', [])->html();
} elseif ($_instance->childHasBeenRendered('fTypbUu')) {
    $componentId = $_instance->getRenderedChildComponentId('fTypbUu');
    $componentTag = $_instance->getRenderedChildComponentTagName('fTypbUu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fTypbUu');
} else {
    $response = \Livewire\Livewire::mount('employe', []);
    $html = $response->html();
    $_instance->logRenderedChild('fTypbUu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

      
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/employes/index.blade.php ENDPATH**/ ?>
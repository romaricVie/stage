<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Biens</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Biens</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->


     <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des biens disponibles</h5>
             <!-- Bien table -->
              <table class="table table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#Identification</th>
                      <th scope="col">Désignation</th>
                      <th scope="col">Disponibilité</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><span class="badge rounded-pill text-bg-primary"><?php echo e($bien->etiquette); ?></span></th>
                        <td><a href="<?php echo e(route('biens.show', ['bien' => $bien->id])); ?>"><?php echo e($bien->name); ?></a></td>
                        <td><span class="badge rounded-pill text-bg-<?= $bien->disponibilite== 'occupe' ? 'warning' : 'success'?>"><?php echo e($bien->disponibilite); ?></span></td>
                      </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
      </div>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/biens/search.blade.php ENDPATH**/ ?>
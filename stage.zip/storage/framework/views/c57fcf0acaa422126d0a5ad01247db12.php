<div>
    

 <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des categories</h5>
              <div class="row">
                  <div class="col-6">
                       <input type="text" name="categorie" wire:model="query"  class="form-control" placeholder="Rechercher une categorie">
                   </div> <!-- End search -->
                    <div class="col-6">
                         Afficher
                        <select wire:model.lazy="perPage" id="Per-page" class="">
                               <?php for($i=5; $i <= 25; $i += 5): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                              <?php endfor; ?>
                         </select>
                          par page
                       </div>
            </div>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Nom</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($categorie->id); ?></th>
                        <td><?php echo e($categorie->name); ?></td>
                        <td>
                           <a href="<?php echo e(route('categories.show', [ 'categorie' => $categorie->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                       </td>
                      </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>

         </div>
          <?php echo e($categories->links()); ?>

      </div>


</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/categories.blade.php ENDPATH**/ ?>
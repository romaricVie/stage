<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('templates/partials/_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
		<section>
			 <?php echo $__env->yieldContent('content'); ?>
		</section>
	<?php echo $__env->make('templates/partials/_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
</body>
</html><?php /**PATH C:\web\patrimoine\stage\resources\views/templates/guest.blade.php ENDPATH**/ ?>
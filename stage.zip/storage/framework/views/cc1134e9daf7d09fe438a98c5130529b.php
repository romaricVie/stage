<div>
    

     <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des sous sous categories</h5>
            <div class="row">
                  <div class="col-6">
                       <input type="text" name="sscategorie" wire:model="query"  class="form-control" placeholder="Rechercher une sous sous categorie">
                   </div> <!-- End search -->
                    <div class="col-6">
                         Afficher
                        <select wire:model.lazy="perPage" id="Per-page" class="">
                               <?php for($i=5; $i <= 25; $i += 5): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                              <?php endfor; ?>
                         </select>
                          par page
                  </div>
            </div>
             <!-- Bien table -->
             <table class="table table-hover ">
                      <thead>
                        <tr>
                           <th scope="col">#</th>
                           <th scope="col">Désignation sous sous categorie</th>
                           <th scope="col">sous categorie</th>
                           <th scope="col">Categorie</th>
                            <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                       <?php $__currentLoopData = $sscategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sscategorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <th scope="row"><?php echo e($sscategorie->id); ?></th>
                            <td><?php echo e($sscategorie->name); ?></td>
                            <td><?php echo e($sscategorie->scategorie->name); ?></td>
                            <td><?php echo e($sscategorie->categorie->name); ?></td>
                            <td>
                               <a href="<?php echo e(route('sscategories.show', ['sscategorie' => $sscategorie->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                           </td>
                          </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
              </table>
         </div>
          <?php echo e($sscategories->links()); ?>

      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/sscategories.blade.php ENDPATH**/ ?>
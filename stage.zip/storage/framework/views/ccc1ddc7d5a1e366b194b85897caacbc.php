<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Affectation details </h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('affectations.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Affectations</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <form  

              action="<?php echo e(route('affectations.destroy',$affectation)); ?>"
              method="POST"
              onsubmit ="return confirm('Etre vous sûr de vouloir supprimer cette affectation ?');"
              class="d-inline" 
        >
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
           <button type="submit" class="btn btn-outline-danger btn-sm m-2"><i class="bi bi-write"></i>Supprimer</button>
      </form>
      
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Détail de l'affectation</h5>
             <!-- Bien table -->
              <p><span class="fw-bold">Nom employé:</span> <a href="<?php echo e(route('employes.show', ['employe' => $affectation->employe->id])); ?>"><?php echo e($affectation->employe->name." ".$affectation->employe->firstname); ?></a></p>
              <p><span class="fw-bold">Contact employé:</span> <?php echo e($affectation->employe->contact); ?></p>
              <p><span class="fw-bold">Email employé:</span> <?php echo e($affectation->employe->email); ?></p>
               <p><span class="fw-bold">Entité :</span> <?php echo e($affectation->employe->entite->name); ?></p>
              <p><span class="fw-bold">Etiquette du biens:</span><span class="badge rounded-pill text-bg-success"><?php echo e($affectation->bien->etiquette); ?></span></p>
              <p><span class="fw-bold">Désignation:</span> <a href="<?php echo e(route('biens.show',['bien' => $affectation->bien->id])); ?>"><?php echo e($affectation->bien->name); ?></a></p>
              <p><span class="fw-bold">Motif affectation:</span> <?php echo e($affectation->motif_affection); ?></p>
              <p><span class="fw-bold">Description:</span> <?php echo e($affectation->description ?? 'Non-definie'); ?></p>
               <p><span class="fw-bold">Affecter le :</span> <?php echo e($affectation->created_at); ?></p>
         </div>
      </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/affectations/show.blade.php ENDPATH**/ ?>
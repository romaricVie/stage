<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Réparations détails</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('reparations.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Réparations</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <form  

              action="<?php echo e(route('reparations.destroy',$reparation)); ?>"
              method="POST"
              onsubmit ="return confirm('Etre vous sûr de vouloir supprimer cette reparation ?');"
              class="d-inline" 
        >
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
           <button type="submit" class="btn btn-outline-danger btn-sm m-2"><i class="bi bi-write"></i>Supprimer</button>
      </form>
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Informations sur la réparation</h5>
             <!-- Bien table -->
              <div>
                  <p><span class="fw-bold">Nom du maintenancier :</span> <?php echo e($reparation->maintenancier); ?></p>
                  <p><span class="fw-bold">Contact maintenancier :</span> <?php echo e($reparation->contact_maintenancier); ?></p>
                  <p><span class="fw-bold">Coût :</span> <?php echo e($reparation->price); ?> FCFA</p>
                  <p><span class="fw-bold">Nom du bien :</span><a href="<?php echo e(route('biens.show',['bien'=>$reparation->bien->id])); ?>"> <?php echo e($reparation->bien->name); ?></a></p>
                  <p><span class="fw-bold">Identifiant :</span> <?php echo e($reparation->bien->etiquette); ?></p>
                  <p><span class="fw-bold">Emplacement :</span> <?php echo e($reparation->bien->emplacement->name); ?></p>
                  <p><span class="fw-bold">Espace :</span> <?php echo e($reparation->bien->espace->name); ?></p>
                  <p><span class="fw-bold">Etat :</span> <?php echo e($reparation->etat); ?></p>
                  <p><span class="fw-bold">Date :</span> <?php echo e($reparation->day); ?>/<?php echo e($reparation->month); ?>/<?php echo e($reparation->year); ?><p>
                  <p><span class="fw-bold">Description panne:</span> <?php echo e($reparation->description_panne); ?><p>
              </div>  
         </div>
      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/reparations/show.blade.php ENDPATH**/ ?>
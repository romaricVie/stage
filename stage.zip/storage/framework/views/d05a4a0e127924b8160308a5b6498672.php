<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Sous categorie</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('scategories.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active"><?php echo e($scategorie->name); ?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des biens de la sous categorie <?php echo e($scategorie->name); ?> (<?php echo e($scategorie->biens->count()); ?>)</h5>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#Identifiant</th>
                      <th scope="col">Designation</th>
                      <th scope="col">Etat</th>
                      <th scope="col">Disponibilité</th>
                      <th scope="col">Entrepôts</th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $scategorie->biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><span class="badge rounded-pill text-bg-primary"><?php echo e($bien->etiquette); ?></span></th>
                        <td><a href="<?php echo e(route('biens.show',['bien'=>$bien->id])); ?>"><?php echo e($bien->name); ?></a></td>
                        <td><?php echo e($bien->etat); ?></td>
                        <td><span class="badge rounded-pill text-bg-<?= $bien->disponibilite== 'occupe' ? 'warning' : 'success'?>"> <?php echo e($bien->disponibilite); ?></span></td>
                        <td><?php echo e($bien->entrepot->name); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
      </div>
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/categories/scategorie_show.blade.php ENDPATH**/ ?>
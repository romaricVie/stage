<div>
    

     <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des emplacements</h5>
               <div class="row">
                 <div class="col-6">
                    <input type="text" name="emplacement" wire:model="query"  class="form-control" placeholder="Rechercher un emplacement">
               </div> <!-- End search -->
                <div class="col-6">
                     Afficher
                      <select wire:model.lazy="perPage" id="Per-page" class="">
                           <?php for($i=5; $i <= 25; $i += 5): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                          <?php endfor; ?>
                      </select>
                      par page
                   </div>
            </div>
             <!-- emplacement table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Désignation emplacement</th>
                      <th scope="col">Entrepôt</th>
                      <th scope="col">Détail</th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $emplacements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emplacement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($emplacement->id); ?></th>
                        <td><?php echo e($emplacement->name); ?></td>
                        <td><?php echo e($emplacement->entrepot->name); ?></td>
                       <td>
                           <a href="<?php echo e(route('emplacements.show', ['emplacement' => $emplacement->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                       </td> 
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
          <?php echo e($emplacements->links()); ?>

      </div>

</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/emplacements.blade.php ENDPATH**/ ?>
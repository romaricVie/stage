<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Emplacements</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/">Home</a></li>
          <li class="breadcrumb-item active">Emplacements</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <a href="<?php echo e(route('emplacements.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter emplacement</button></a>
          
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('emplacements', [])->html();
} elseif ($_instance->childHasBeenRendered('UIlllia')) {
    $componentId = $_instance->getRenderedChildComponentId('UIlllia');
    $componentTag = $_instance->getRenderedChildComponentTagName('UIlllia');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UIlllia');
} else {
    $response = \Livewire\Livewire::mount('emplacements', []);
    $html = $response->html();
    $_instance->logRenderedChild('UIlllia', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  

    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/emplacement_index.blade.php ENDPATH**/ ?>
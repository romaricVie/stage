<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Entrepots</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/">Home</a></li>
          <li class="breadcrumb-item active">Entrepôts</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
       <a href="<?php echo e(route('entrepots.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter un entrepôt</button></a>
      <div class="card">
         <div class="card-body">
            <h5 class="card-title">Liste des entrepots (<?php echo e($entrepots->count()); ?>)</h5>
             <!-- Bien table -->
              <table class="table table-hover ">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Désignation entrepot </th>
                      <th scope="col">Adresse géographique</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                       <?php $__currentLoopData = $entrepots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrepot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($entrepot->id); ?></th>
                        <td><?php echo e($entrepot->name); ?></td>
                        <td><?php echo e($entrepot->adresse_geographique); ?></td>
                        <td>
                           <a href="<?php echo e(route('entrepots.show',['entrepot' => $entrepot->id])); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="bi bi-eye"></i> Voir details</button></a>
                       </td>
                      </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
          </table>
         </div>
           <?php echo e($entrepots->links()); ?>

      </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/index.blade.php ENDPATH**/ ?>
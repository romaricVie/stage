<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Categories</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Categories</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <a href="<?php echo e(route('categories.create')); ?>"><button type="button" class="btn btn-outline-success btn-md m-2"><i class="bi bi-plus"></i> Ajouter Categorie</button></a>

    
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('categories', [])->html();
} elseif ($_instance->childHasBeenRendered('trJ3VQr')) {
    $componentId = $_instance->getRenderedChildComponentId('trJ3VQr');
    $componentTag = $_instance->getRenderedChildComponentTagName('trJ3VQr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('trJ3VQr');
} else {
    $response = \Livewire\Livewire::mount('categories', []);
    $html = $response->html();
    $_instance->logRenderedChild('trJ3VQr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/categories/index.blade.php ENDPATH**/ ?>
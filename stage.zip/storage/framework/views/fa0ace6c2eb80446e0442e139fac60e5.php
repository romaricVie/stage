<div>
    

    <div class="card">
         <div class="card-body">
            <h5 class="card-title">Formulaire de recherche</h5>
             <!-- Bien Form -->
              <form 
                 method="POST"
                 class="row g-3" 
                 action="<?php echo e(route('biens.search')); ?>" 
                 >

                 <?php echo csrf_field(); ?>

                <div class="col-6">
                    <label for="inputCategorie" class="form-label">Categorie <span class="text-danger"> *</span></label>
                    <select

                           class="form-select form-select-sm" 
                           name="categorie_id"  id="inputCategorie" 
                           aria-label=".form-select-sm example"
                           required
                           wire:model.lazy="categorie"
                           >
                         <option value="">Choisir une categorie...</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                  </select>
                </div> <!--End Categorie-->
                <div class="col-6">
                  <label for="inputScategorie" class="form-label">Sous categorie <span class="text-danger"> *</span></label>
                    <select 
                    
                       class="form-select form-select-sm" 
                       id="inputScategorie" 
                       aria-label=".form-select-sm example"
                       name="scategorie_id" 
                       required
                       wire:model.lazy="scategorie"
                       >
                         <option value="">Choisir une sous categorie...</option>
                         <?php $__currentLoopData = $scategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scategorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($scategorie->id); ?>"><?php echo e($scategorie->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div> <!--End sous categorie -->

                <div class="col-6">
                    <label for="inputSscategorie" class="form-label">Sous sous categorie<span class="text-danger"> *</span></label>
                      <select 

                       class="form-select form-select-sm" 
                       id="inputSscategorie"
                       aria-label=".form-select-sm example"
                       required
                       name ="sscategorie_id"
                       >
                         <option value="">Choisir une sous sous categorie...</option>
                        <?php $__currentLoopData = $sscategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sscategorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($sscategorie->id); ?>"><?php echo e($sscategorie->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                  </select>
                </div> <!-- Sous sous categorie -->
              
               
                <div class="">
                   <button type="submit" class="btn btn-success">Afficher</button>
                </div><!--End submit-->
              </form>
         </div>
      </div>
</div>
<?php /**PATH C:\web\patrimoine\stage\resources\views/livewire/search.blade.php ENDPATH**/ ?>
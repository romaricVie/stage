<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Espace</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('espaces.index')); ?>">Home</a></li>
          <li class="breadcrumb-item active">Espace</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      
       <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
               </script>
           <?php endif; ?>
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('espace-create', [])->html();
} elseif ($_instance->childHasBeenRendered('Mkst0DH')) {
    $componentId = $_instance->getRenderedChildComponentId('Mkst0DH');
    $componentTag = $_instance->getRenderedChildComponentTagName('Mkst0DH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Mkst0DH');
} else {
    $response = \Livewire\Livewire::mount('espace-create', []);
    $html = $response->html();
    $_instance->logRenderedChild('Mkst0DH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
    </section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/espace_create.blade.php ENDPATH**/ ?>
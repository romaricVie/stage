<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Liste des Biens d'un entrepot</title>
</head>
<body>
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('bien-entrepot-pdf', ['entrepot' => $entrepot])->html();
} elseif ($_instance->childHasBeenRendered('NFavv7m')) {
    $componentId = $_instance->getRenderedChildComponentId('NFavv7m');
    $componentTag = $_instance->getRenderedChildComponentTagName('NFavv7m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NFavv7m');
} else {
    $response = \Livewire\Livewire::mount('bien-entrepot-pdf', ['entrepot' => $entrepot]);
    $html = $response->html();
    $_instance->logRenderedChild('NFavv7m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
</body>
</html><?php /**PATH C:\web\patrimoine\stage\resources\views/entrepots/entrepot_pdf.blade.php ENDPATH**/ ?>